import { Outlet, Link, useLocation } from "react-router";
import { ShoppingCart, Package, History, User, LogOut, UtensilsCrossed } from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { useApp } from "../context/AppContext";

export function CustomerLayout() {
  const location = useLocation();
  const { cart } = useApp();

  const navItems = [
    { path: "/customer", label: "Browse", icon: UtensilsCrossed },
    { path: "/customer/cart", label: "Cart", icon: ShoppingCart, badge: cart.length },
    { path: "/customer/orders", label: "Orders", icon: Package },
    { path: "/customer/history", label: "History", icon: History },
    { path: "/customer/profile", label: "Profile", icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <UtensilsCrossed className="w-8 h-8 text-orange-500" />
              <span className="text-xl font-bold">FoodHub</span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors relative ${
                      isActive
                        ? "text-orange-500 bg-orange-50"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                    {item.badge !== undefined && item.badge > 0 && (
                      <Badge className="bg-orange-500 text-white">{item.badge}</Badge>
                    )}
                  </Link>
                );
              })}
            </nav>
            <Link to="/login">
              <Button variant="ghost" size="sm">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-50">
        <div className="flex justify-around py-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1 px-3 py-2 relative ${
                  isActive ? "text-orange-500" : "text-gray-600"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <Badge className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs px-1 min-w-[20px] h-5">
                    {item.badge}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Main Content */}
      <main className="pb-20 md:pb-8">
        <Outlet />
      </main>
    </div>
  );
}
