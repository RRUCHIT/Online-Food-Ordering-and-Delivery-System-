import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Search, Star } from "lucide-react";
import axios from "axios";

import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent, CardFooter, CardHeader } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../components/ui/dialog";
import { Badge } from "../../components/ui/badge";

import { toast } from "sonner";

export function RestaurantManagement() {

  const [searchQuery, setSearchQuery] = useState("");
  const [restaurants, setRestaurants] = useState([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRestaurant, setEditingRestaurant] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    cuisine: "",
    deliveryTime: "",
    rating: "",
  });

  /* FETCH RESTAURANTS */

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {

    try {

      const res = await axios.get("http://localhost:5000/api/restaurants");

      setRestaurants(res.data);

    } catch (error) {

      console.log(error);

    }

  };

  /* FILTER SEARCH */

  const filteredRestaurants = restaurants.filter(
    (restaurant) =>
      restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.cuisine.toLowerCase().includes(searchQuery.toLowerCase())
  );

  /* ADD NEW */

  const handleAddNew = () => {

    setEditingRestaurant(null);

    setFormData({
      name: "",
      description: "",
      cuisine: "",
      deliveryTime: "",
      rating: "",
    });

    setIsDialogOpen(true);

  };

  /* EDIT */

  const handleEdit = (restaurant) => {

    setEditingRestaurant(restaurant);

    setFormData({
      name: restaurant.name,
      description: restaurant.description,
      cuisine: restaurant.cuisine,
      deliveryTime: restaurant.deliveryTime,
      rating: restaurant.rating.toString(),
    });

    setIsDialogOpen(true);

  };

  /* SAVE */

  const handleSave = async () => {

    if (!formData.name || !formData.cuisine) {

      toast.error("Please fill in required fields");
      return;

    }

    try {

      if (editingRestaurant) {

        await axios.put(
          `http://localhost:5000/api/restaurants/${editingRestaurant._id}`,
          formData
        );

        toast.success("Restaurant updated successfully");

      } else {

        await axios.post(
          "http://localhost:5000/api/restaurants",
          formData
        );

        toast.success("Restaurant added successfully");

      }

      fetchRestaurants();

      setIsDialogOpen(false);

    } catch (error) {

      console.log(error);

      toast.error("Operation failed");

    }

  };

  /* DELETE */

  const handleDelete = async (id) => {

    try {

      await axios.delete(
        `http://localhost:5000/api/restaurants/${id}`
      );

      toast.success("Restaurant removed");

      fetchRestaurants();

    } catch (error) {

      console.log(error);

    }

  };

  return (

    <div>

      {/* HEADER */}

      <div className="flex items-center justify-between mb-6">

        <div>
          <h1 className="text-3xl font-bold mb-2">Restaurant Management</h1>
          <p className="text-gray-600">
            Add or remove restaurants from the platform
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>

          <DialogTrigger asChild>

            <Button
              className="bg-blue-500 hover:bg-blue-600"
              onClick={handleAddNew}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Restaurant
            </Button>

          </DialogTrigger>

          <DialogContent className="max-w-2xl">

            <DialogHeader>

              <DialogTitle>
                {editingRestaurant ? "Edit Restaurant" : "Add Restaurant"}
              </DialogTitle>

              <DialogDescription>
                Fill restaurant details
              </DialogDescription>

            </DialogHeader>

            <div className="space-y-4">

              <div>
                <Label>Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                />
              </div>

              <div>
                <Label>Description</Label>
                <Input
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                />
              </div>

              <div className="grid grid-cols-2 gap-4">

                <div>
                  <Label>Cuisine</Label>
                  <Input
                    value={formData.cuisine}
                    onChange={(e) =>
                      setFormData({ ...formData, cuisine: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label>Delivery Time</Label>
                  <Input
                    value={formData.deliveryTime}
                    onChange={(e) =>
                      setFormData({ ...formData, deliveryTime: e.target.value })
                    }
                  />
                </div>

              </div>

              <div>
                <Label>Rating</Label>
                <Input
                  type="number"
                  value={formData.rating}
                  onChange={(e) =>
                    setFormData({ ...formData, rating: e.target.value })
                  }
                />
              </div>

            </div>

            <DialogFooter>

              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
              >
                Cancel
              </Button>

              <Button
                className="bg-blue-500 hover:bg-blue-600"
                onClick={handleSave}
              >
                Save
              </Button>

            </DialogFooter>

          </DialogContent>

        </Dialog>

      </div>


      {/* SEARCH */}

      <div className="mb-6">

        <div className="relative max-w-md">

          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />

          <Input
            placeholder="Search restaurants..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

        </div>

      </div>


      {/* RESTAURANT GRID */}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

        {filteredRestaurants.map((restaurant) => (

          <Card key={restaurant._id}>

            <CardHeader>

              <div className="flex justify-between">

                <h3 className="font-bold text-xl">
                  {restaurant.name}
                </h3>

                <Badge className="bg-yellow-500">

                  <Star className="w-3 h-3 mr-1 fill-white" />

                  {restaurant.rating}

                </Badge>

              </div>

              <Badge variant="outline">
                {restaurant.cuisine}
              </Badge>

            </CardHeader>

            <CardContent>

              <p className="text-sm text-gray-600 mb-2">
                {restaurant.description}
              </p>

              <p className="text-sm text-gray-500">
                Delivery: {restaurant.deliveryTime}
              </p>

            </CardContent>

            <CardFooter className="flex gap-2">

              <Button
                variant="outline"
                className="flex-1"
                onClick={() => handleEdit(restaurant)}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>

              <Button
                variant="outline"
                className="flex-1 text-red-500"
                onClick={() => handleDelete(restaurant._id)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Remove
              </Button>

            </CardFooter>

          </Card>

        ))}

      </div>

    </div>

  );

}