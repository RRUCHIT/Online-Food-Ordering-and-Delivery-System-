import { DollarSign, TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import axios from "axios";
import { useEffect, useState } from "react";

export function RevenueReports() {

  const [stats, setStats] = useState({
    totalOrders: 0,
    totalRevenue: 0,
    platformFee: 0,
    restaurantRevenue: 0,
    completionRate: 0
  });

  useEffect(() => {

    axios
      .get("http://localhost:5000/api/admin/revenue")
      .then((res) => {
        setStats(res.data);
      })
      .catch((err) => {
        console.log(err);
      });

  }, []);

  const statsCards = [
    {
      title: "Total Revenue",
      value: `$${stats.totalRevenue.toFixed(2)}`,
      change: "+12%",
      isPositive: true,
      icon: DollarSign,
    },
    {
      title: "Platform Fee (15%)",
      value: `$${stats.platformFee.toFixed(2)}`,
      change: "+8%",
      isPositive: true,
      icon: TrendingUp,
    },
    {
      title: "Restaurant Revenue",
      value: `$${stats.restaurantRevenue.toFixed(2)}`,
      change: "+10%",
      isPositive: true,
      icon: DollarSign,
    },
    {
      title: "Order Completion",
      value: `${stats.completionRate.toFixed(1)}%`,
      change: "-2%",
      isPositive: false,
      icon: TrendingDown,
    },
  ];

  return (
    <div>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Revenue Reports</h1>
          <p className="text-gray-600">Track platform revenue and performance</p>
        </div>

        <Select defaultValue="this_month">
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="this_week">This Week</SelectItem>
            <SelectItem value="this_month">This Month</SelectItem>
            <SelectItem value="this_year">This Year</SelectItem>
          </SelectContent>
        </Select>

      </div>

      {/* Stats */}

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

        {statsCards.map((stat, index) => {

          const Icon = stat.icon;

          return (

            <Card key={index}>

              <CardContent className="p-6">

                <div className="flex items-center justify-between mb-4">

                  <Icon className="w-8 h-8 text-blue-500" />

                  {stat.isPositive ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}

                </div>

                <p className="text-sm text-gray-600 mb-1">{stat.title}</p>

                <p className="text-3xl font-bold mb-1">{stat.value}</p>

                <p
                  className={`text-xs ${
                    stat.isPositive ? "text-green-600" : "text-red-600"
                  }`}
                >
                  {stat.change} from last period
                </p>

              </CardContent>

            </Card>

          );

        })}

      </div>


      {/* Summary */}

      <div className="grid md:grid-cols-2 gap-6">

        <Card>

          <CardHeader>
            <CardTitle>Platform Summary</CardTitle>
          </CardHeader>

          <CardContent>

            <div className="space-y-3">

              <div className="flex justify-between">
                <span className="text-gray-600">Total Orders</span>
                <span className="font-semibold">{stats.totalOrders}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Total Revenue</span>
                <span className="font-semibold">
                  ${stats.totalRevenue.toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Platform Fee</span>
                <span className="font-semibold">
                  ${stats.platformFee.toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Completion Rate</span>
                <span className="font-semibold">
                  {stats.completionRate.toFixed(1)}%
                </span>
              </div>

            </div>

          </CardContent>

        </Card>

      </div>

    </div>
  );
}