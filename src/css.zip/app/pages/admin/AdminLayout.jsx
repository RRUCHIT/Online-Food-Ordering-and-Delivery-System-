import { Link, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Store,
  ShoppingBag,
  DollarSign,
  MessageSquare,
  ArrowLeft,
} from "lucide-react";

export function AdminLayout() {

  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen">

      {/* Sidebar */}

      <div className="w-64 bg-gray-900 text-white p-6">

        <h2 className="text-2xl font-bold mb-8">Admin Panel</h2>

        <nav className="space-y-4">

          <Link
            to="/admin"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <LayoutDashboard size={18} />
            Dashboard
          </Link>

          <Link
            to="/admin/restaurants"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <Store size={18} />
            Restaurants
          </Link>

          <Link
            to="/admin/orders"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <ShoppingBag size={18} />
            Orders
          </Link>

          <Link
            to="/admin/revenue"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <DollarSign size={18} />
            Revenue
          </Link>

          <Link
            to="/admin/complaints"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <MessageSquare size={18} />
            Complaints
          </Link>

        </nav>

        {/* Back Button */}

        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 mt-10 text-gray-300 hover:text-white"
        >
          <ArrowLeft size={16} />
          Back to Home
        </button>

      </div>

      {/* Page Content */}

      <div className="flex-1 p-8 bg-gray-50">
        <Outlet />
      </div>

    </div>
  );
}