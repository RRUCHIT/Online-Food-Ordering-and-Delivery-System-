import { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Search } from "lucide-react";
import axios from "axios";

import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Card, CardContent, CardFooter } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { toast } from "sonner";

export function MenuManagement() {

  const [menuItems, setMenuItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {

    axios
      .get("http://localhost:5000/api/menu")
      .then((res) => {

        setMenuItems(res.data);

      })
      .catch((err) => console.log(err));

  }, []);


  const filteredItems = menuItems.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );


  const deleteItem = async (id) => {

    try {

      await axios.delete(`http://localhost:5000/api/menu/${id}`);

      setMenuItems(menuItems.filter((item) => item._id !== id));

      toast.success("Item deleted");

    } catch (error) {

      toast.error("Delete failed");

    }

  };


  return (

    <div>

      <h1 className="text-3xl font-bold mb-6">
        Menu Management
      </h1>


      <div className="mb-6">

        <Input
          placeholder="Search menu items..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />

      </div>


      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

        {filteredItems.map((item) => (

          <Card key={item._id}>

            <img
              src={item.image}
              className="h-48 w-full object-cover"
            />

            <CardContent className="p-4">

              <h3 className="font-bold text-lg">
                {item.name}
              </h3>

              <Badge className="mt-2">
                {item.category}
              </Badge>

              <p className="text-orange-500 font-bold mt-2">
                ${item.price}
              </p>

            </CardContent>

            <CardFooter>

              <Button
                variant="outline"
                onClick={() => deleteItem(item._id)}
              >
                <Trash2 className="w-4 h-4 mr-2"/>
                Delete
              </Button>

            </CardFooter>

          </Card>

        ))}

      </div>

    </div>

  );

}