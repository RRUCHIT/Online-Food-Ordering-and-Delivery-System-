import { Link, Outlet } from "react-router-dom";
import { LayoutDashboard, ClipboardList, Menu, BarChart3 } from "lucide-react";

export function RestaurantLayout() {

  return (
    <div className="flex min-h-screen">

      {/* Sidebar */}

      <div className="w-64 bg-gray-900 text-white p-6">

        <h2 className="text-2xl font-bold mb-8">Restaurant Panel</h2>

        <nav className="space-y-4">

          <Link
            to="/restaurant"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <LayoutDashboard size={18} />
            Dashboard
          </Link>

          <Link
            to="/restaurant/orders"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <ClipboardList size={18} />
            Orders
          </Link>

          <Link
            to="/restaurant/menu"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <Menu size={18} />
            Menu
          </Link>

          <Link
            to="/restaurant/sales"
            className="flex items-center gap-2 hover:text-orange-400"
          >
            <BarChart3 size={18} />
            Sales
          </Link>

        </nav>
      </div>

      {/* Page Content */}

      <div className="flex-1 p-8 bg-gray-50">
        <Outlet />
      </div>

    </div>
  );
}