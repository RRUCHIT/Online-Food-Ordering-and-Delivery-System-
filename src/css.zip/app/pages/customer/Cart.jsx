import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import axios from "axios";

import { Button } from "../../components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../../components/ui/card";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Input } from "../../components/ui/input";
import { Separator } from "../../components/ui/separator";

import { useApp } from "../../context/AppContext";
import { toast } from "sonner";

export function Cart() {

  const navigate = useNavigate();

  const {
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart
  } = useApp();

  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");

  const subtotal = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const deliveryFee = subtotal > 0 ? 5.99 : 0;

  const tax = subtotal * 0.1;

  const total = subtotal + deliveryFee + tax;


  const handlePlaceOrder = async () => {

    if (cart.length === 0) {
      toast.error("Cart is empty");
      return;
    }

    if (!deliveryAddress) {
      toast.error("Enter delivery address");
      return;
    }

    if (!phone) {
      toast.error("Enter phone number");
      return;
    }

    try {

      await axios.post(
        "http://localhost:5000/api/orders",
        {
          items: cart,
          total: total,
          restaurantName: cart[0].restaurantName,
          deliveryAddress,
          phone,
          notes,
          status: "pending"
        }
      );

      clearCart();

      toast.success("Order placed successfully!");

      navigate("/orders");

    } catch (error) {

      console.log(error);

      toast.error("Order failed");

    }

  };


  if (cart.length === 0) {

    return (
      <div className="container mx-auto px-4 py-6">

        <div className="max-w-2xl mx-auto text-center py-16">

          <ShoppingBag className="w-24 h-24 mx-auto text-gray-300 mb-4" />

          <h2 className="text-2xl font-bold mb-2">
            Your cart is empty
          </h2>

          <p className="text-gray-600 mb-6">
            Add some delicious food items
          </p>

          <Button
            className="bg-orange-500 hover:bg-orange-600"
            onClick={() => navigate("/customer")}
          >
            Browse Menu
          </Button>

        </div>

      </div>
    );

  }


  return (

    <div className="container mx-auto px-4 py-6">

      <h1 className="text-3xl font-bold mb-6">
        Shopping Cart
      </h1>


      <div className="grid lg:grid-cols-3 gap-6">


        {/* CART ITEMS */}

        <div className="lg:col-span-2 space-y-4">

          {cart.map((item) => (

            <Card key={item.id}>

              <CardContent className="p-4">

                <div className="flex gap-4">

                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-24 h-24 object-cover rounded"
                  />

                  <div className="flex-1">

                    <h3 className="font-bold text-lg">
                      {item.name}
                    </h3>

                    <p className="text-sm text-gray-600">
                      {item.restaurantName}
                    </p>

                    <p className="text-orange-500 font-semibold mt-1">
                      ${item.price.toFixed(2)}
                    </p>

                  </div>


                  <div className="flex flex-col items-end justify-between">

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>


                    <div className="flex items-center gap-2">

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          updateCartQuantity(item.id, item.quantity - 1)
                        }
                      >
                        <Minus className="w-3 h-3" />
                      </Button>

                      <span className="w-8 text-center font-semibold">
                        {item.quantity}
                      </span>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          updateCartQuantity(item.id, item.quantity + 1)
                        }
                      >
                        <Plus className="w-3 h-3" />
                      </Button>

                    </div>

                  </div>

                </div>

              </CardContent>

            </Card>

          ))}

        </div>



        {/* ORDER SUMMARY */}

        <div>

          <Card className="sticky top-20">

            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>


            <CardContent className="space-y-4">

              <div>

                <Label>Phone Number</Label>

                <Input
                  placeholder="Enter phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />

              </div>


              <div>

                <Label>Delivery Address</Label>

                <Textarea
                  value={deliveryAddress}
                  onChange={(e) =>
                    setDeliveryAddress(e.target.value)
                  }
                  placeholder="Enter your delivery address"
                  rows={3}
                />

              </div>


              <div>

                <Label>Order Notes</Label>

                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Special instructions"
                  rows={2}
                />

              </div>


              <Separator />


              <div className="space-y-2 text-sm">

                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>${deliveryFee.toFixed(2)}</span>
                </div>

                <div className="flex justify-between">
                  <span>Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>

                <Separator />

                <div className="flex justify-between font-bold text-lg">

                  <span>Total</span>

                  <span className="text-orange-500">
                    ${total.toFixed(2)}
                  </span>

                </div>

              </div>

            </CardContent>


            <CardFooter>

              <Button
                className="w-full bg-orange-500 hover:bg-orange-600"
                onClick={handlePlaceOrder}
              >
                Place Order
              </Button>

            </CardFooter>

          </Card>

        </div>

      </div>

    </div>

  );

}