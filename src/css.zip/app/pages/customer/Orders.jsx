import { useEffect, useState } from "react";
import axios from "axios";
import { Card, CardContent } from "../../components/ui/card";

export function Orders() {

  const [orders, setOrders] = useState([]);

  const customerId = "c1"; // later replace with logged in user id


  const fetchOrders = async () => {

    try {

      const res = await axios.get(
        `http://localhost:5000/api/orders/customer/${customerId}`
      );

      setOrders(res.data);

    } catch (error) {

      console.log(error);

    }

  };


  useEffect(() => {

    fetchOrders();

    const interval = setInterval(fetchOrders, 5000);

    return () => clearInterval(interval);

  }, []);


  const getStatusColor = (status) => {

    switch (status) {

      case "pending":
        return "bg-yellow-500";

      case "preparing":
        return "bg-blue-500";

      case "out_for_delivery":
        return "bg-orange-500";

      case "delivered":
        return "bg-green-500";

      default:
        return "bg-gray-500";

    }

  };


  const steps = [
    "pending",
    "preparing",
    "out_for_delivery",
    "delivered"
  ];


  return (

    <div className="container mx-auto px-4 py-6">

      <h1 className="text-3xl font-bold mb-6">
        Your Orders
      </h1>

      {orders.length === 0 ? (

        <p>No orders yet</p>

      ) : (

        <div className="space-y-6">

          {orders.map((order) => (

            <Card key={order._id}>

              <CardContent className="p-6">

                <div className="flex justify-between items-center mb-4">

                  <div>

                    <h2 className="font-bold text-lg">
                      Order #{order._id}
                    </h2>

                    <p className="text-sm text-gray-600">
                      Restaurant: {order.restaurantName}
                    </p>

                    <p className="text-sm text-gray-600">
                      Total: ${order.total}
                    </p>

                  </div>


                  <span
                    className={`text-white px-3 py-1 rounded ${getStatusColor(order.status)}`}
                  >
                    {order.status.replace("_", " ")}
                  </span>

                </div>


                {/* Order Items */}

                <div className="mb-4">

                  {order.items.map((item, index) => (

                    <p key={index} className="text-sm">

                      {item.quantity} × {item.name}

                    </p>

                  ))}

                </div>


                {/* Order Tracking Progress */}

                <div className="flex justify-between mt-6">

                  {steps.map((step, index) => {

                    const stepIndex = steps.indexOf(order.status);

                    return (

                      <div
                        key={index}
                        className="flex flex-col items-center flex-1"
                      >

                        <div
                          className={`w-6 h-6 rounded-full 
                          ${index <= stepIndex
                            ? "bg-green-500"
                            : "bg-gray-300"
                          }`}
                        ></div>

                        <p className="text-xs mt-2 text-center">

                          {step.replace("_", " ")}

                        </p>

                      </div>

                    );

                  })}

                </div>

              </CardContent>

            </Card>

          ))}

        </div>

      )}

    </div>

  );

}