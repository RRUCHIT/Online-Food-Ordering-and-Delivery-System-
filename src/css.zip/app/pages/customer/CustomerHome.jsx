import { useState ,useEffect} from "react";
import { Search, Star, Clock, Plus, ShoppingCart } from "lucide-react";
import { Input } from "../../components/ui/input";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { useApp } from "../../context/AppContext";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export function CustomerHome() {

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [restaurants, setRestaurants] = useState([]);
  const [menuItems, setMenuItems] = useState([]);

  const { addToCart, cart } = useApp();
  const navigate = useNavigate();

  useEffect(() => {

    axios
      .get("http://localhost:5000/api/restaurants")
      .then((res) => {

        setRestaurants(res.data);

      });

  }, []);


  useEffect(() => {

    if(!selectedRestaurant) return;

    axios
      .get(`http://localhost:5000/api/menu/${selectedRestaurant}`)
      .then((res) => {

        setMenuItems(res.data);

      });

  }, [selectedRestaurant]);


  const handleAddToCart = (item) => {

    addToCart(item);

    toast.success(`${item.name} added to cart!`);

  };


  const categories = Array.from(
    new Set(menuItems.map((item) => item.category))
  );


  return (

    <div className="container mx-auto px-4 py-6">


      <div className="flex justify-between items-center mb-8">

        <div>

          <h1 className="text-3xl font-bold">
            Discover Delicious Food
          </h1>

          <p className="text-gray-600">
            Order from the best restaurants near you
          </p>

        </div>


        <Button
          className="relative bg-orange-500 hover:bg-orange-600"
          onClick={() => navigate("/cart")}
        >

          <ShoppingCart className="w-5 h-5 mr-2"/>

          Cart

          {cart.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
              {cart.length}
            </span>
          )}

        </Button>

      </div>



      <div className="mb-8">

        <div className="relative">

          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"/>

          <Input
            placeholder="Search restaurants..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

        </div>

      </div>



      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

        {restaurants.map((restaurant) => (

          <Card
            key={restaurant._id}
            className="cursor-pointer"
            onClick={() => setSelectedRestaurant(restaurant._id)}
          >

            <img
              src={restaurant.image}
              className="h-48 w-full object-cover"
            />

            <CardHeader>

              <h3 className="font-bold text-xl">
                {restaurant.name}
              </h3>

              <p className="text-sm text-gray-600">
                {restaurant.cuisine}
              </p>

            </CardHeader>

          </Card>

        ))}

      </div>


      {selectedRestaurant && (

        <div className="mt-10">

          <h2 className="text-2xl font-bold mb-6">
            Menu
          </h2>


          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            {menuItems.map((item) => (

              <Card key={item._id}>

                <img
                  src={item.image}
                  className="h-48 w-full object-cover"
                />

                <CardHeader>

                  <h3 className="font-bold text-lg">
                    {item.name}
                  </h3>

                </CardHeader>

                <CardContent>

                  <p className="text-gray-600">
                    {item.description}
                  </p>

                  <p className="font-bold text-orange-500 mt-2">
                    ${item.price}
                  </p>

                </CardContent>

                <CardFooter>

                  <Button
                    className="w-full bg-orange-500"
                    onClick={() => handleAddToCart(item)}
                  >

                    <Plus className="w-4 h-4 mr-2"/>

                    Add to Cart

                  </Button>

                </CardFooter>

              </Card>

            ))}

          </div>

        </div>

      )}

    </div>

  );

}