import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { UtensilsCrossed } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { toast } from "sonner";

export function Login() {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      const res = await axios.post(
        "http://localhost:5000/api/auth/login",
        {
          email,
          password
        }
      );

      const { token, user } = res.data;

      // store login info
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));

      toast.success("Login successful!");

      // redirect based on role
      if (user.role === "admin") {
        navigate("/admin");
      }

      else if (user.role === "restaurant") {
        navigate("/restaurant");
      }

      else {
        navigate("/customer");
      }

    } catch (error) {

      toast.error(
        error.response?.data?.message || "Login failed"
      );

    }

  };

  return (

    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center p-4">

      <Card className="w-full max-w-md">

        <CardHeader className="space-y-4 text-center">

          <div className="flex items-center justify-center gap-2">
            <UtensilsCrossed className="w-10 h-10 text-orange-500" />
            <span className="text-2xl font-bold">FoodHub</span>
          </div>

          <CardTitle>Welcome Back</CardTitle>

          <CardDescription>
            Sign in to your account
          </CardDescription>

        </CardHeader>

        <CardContent>

          <form onSubmit={handleSubmit} className="space-y-4">

            <div className="space-y-2">

              <Label>Email</Label>

              <Input
                type="email"
                placeholder="john@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

            </div>


            <div className="space-y-2">

              <Label>Password</Label>

              <Input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

            </div>


            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600"
            >
              Sign In
            </Button>


            <div className="text-center text-sm">

              <span className="text-gray-600">
                Don't have an account?
              </span>

              <Link
                to="/register"
                className="text-orange-500 hover:underline font-medium ml-1"
              >
                Sign up
              </Link>

            </div>


            <div className="text-center">

              <Link
                to="/"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                ← Back to home
              </Link>

            </div>

          </form>

        </CardContent>

      </Card>

    </div>
  );
}