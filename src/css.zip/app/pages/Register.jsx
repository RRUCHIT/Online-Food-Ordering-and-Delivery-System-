import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { UtensilsCrossed } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { toast } from "sonner";

export function Register() {

  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    userType: "customer",
  });

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    try {

      await axios.post(
        "http://localhost:5000/api/auth/register",
        {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role: formData.userType
        }
      );

      toast.success("Registration successful!");

      navigate("/login");

    } catch (error) {

      toast.error(
        error.response?.data?.message || "Registration failed"
      );

    }

  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center p-4">

      <Card className="w-full max-w-md">

        <CardHeader className="space-y-4 text-center">

          <div className="flex items-center justify-center gap-2">
            <UtensilsCrossed className="w-10 h-10 text-orange-500" />
            <span className="text-2xl font-bold">FoodHub</span>
          </div>

          <CardTitle>Create Account</CardTitle>
          <CardDescription>
            Sign up to start ordering delicious food
          </CardDescription>

        </CardHeader>

        <CardContent>

          <form onSubmit={handleSubmit} className="space-y-4">

            <div className="space-y-2">
              <Label>User Type</Label>

              <Select
                value={formData.userType}
                onValueChange={(value) =>
                  setFormData({ ...formData, userType: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select user type" />
                </SelectTrigger>

                <SelectContent>
                  <SelectItem value="customer">Customer</SelectItem>
                  <SelectItem value="restaurant">Restaurant</SelectItem>
                </SelectContent>

              </Select>
            </div>


            <div className="space-y-2">

              <Label>Full Name</Label>

              <Input
                placeholder="John Doe"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />

            </div>


            <div className="space-y-2">

              <Label>Email</Label>

              <Input
                type="email"
                placeholder="john@example.com"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                required
              />

            </div>


            <div className="space-y-2">

              <Label>Password</Label>

              <Input
                type="password"
                placeholder="Create a password"
                value={formData.password}
                onChange={(e) =>
                  setFormData({ ...formData, password: e.target.value })
                }
                required
              />

            </div>


            <div className="space-y-2">

              <Label>Confirm Password</Label>

              <Input
                type="password"
                placeholder="Confirm your password"
                value={formData.confirmPassword}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    confirmPassword: e.target.value
                  })
                }
                required
              />

            </div>


            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600"
            >
              Create Account
            </Button>


            <div className="text-center text-sm">
              <span className="text-gray-600">
                Already have an account?
              </span>

              <Link
                to="/login"
                className="text-orange-500 hover:underline font-medium ml-1"
              >
                Sign in
              </Link>
            </div>


            <div className="text-center">
              <Link
                to="/"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                ← Back to home
              </Link>
            </div>

          </form>

        </CardContent>

      </Card>

    </div>
  );
}