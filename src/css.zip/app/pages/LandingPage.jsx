import { Link } from "react-router-dom";
import { UtensilsCrossed, Clock, ShoppingBag, Star, ArrowRight } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";

export function LandingPage() {

  const features = [
    {
      icon: UtensilsCrossed,
      title: "Wide Selection",
      description: "Choose from hundreds of restaurants and cuisines",
    },
    {
      icon: Clock,
      title: "Fast Delivery",
      description: "Get your food delivered hot and fresh in 30 minutes",
    },
    {
      icon: Star,
      title: "Quality Food",
      description: "Only the best restaurants with top ratings",
    },
    {
      icon: ShoppingBag,
      title: "Easy Ordering",
      description: "Simple and intuitive ordering process",
    },
  ];

  return (
    <div className="min-h-screen">

      {/* Header */}

      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">

          <div className="flex items-center justify-between">

            <div className="flex items-center gap-2">
              <UtensilsCrossed className="w-8 h-8 text-orange-500" />
              <span className="text-2xl font-bold">FoodHub</span>
            </div>

            <div className="flex items-center gap-4">

              <Link to="/login">
                <Button variant="ghost">
                  Login
                </Button>
              </Link>

              <Link to="/register">
                <Button className="bg-orange-500 hover:bg-orange-600">
                  Sign Up
                </Button>
              </Link>

            </div>

          </div>

        </div>
      </header>


      {/* Hero Section */}

      <section className="relative bg-gradient-to-br from-orange-500 to-red-500 text-white py-24">

        <div className="container mx-auto px-4">

          <div className="max-w-3xl">

            <h1 className="text-5xl font-bold mb-6">
              Delicious Food Delivered to Your Doorstep
            </h1>

            <p className="text-xl mb-8 text-orange-50">
              Order from your favorite restaurants and get fresh,
              hot food delivered quickly and safely.
            </p>

            <div className="flex gap-4">

              <Link to="/register">
                <Button
                  size="lg"
                  className="bg-white text-orange-500 hover:bg-gray-100"
                >
                  Get Started
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>

              <Link to="/customer">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                >
                  Browse Menu
                </Button>
              </Link>

            </div>

          </div>

        </div>

        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>

      </section>


      {/* Features Section */}

      <section className="py-20 bg-white">

        <div className="container mx-auto px-4">

          <h2 className="text-3xl font-bold text-center mb-12">
            Why Choose FoodHub?
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">

            {features.map((feature, index) => {

              const Icon = feature.icon;

              return (

                <Card key={index} className="text-center">

                  <CardContent className="pt-6">

                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">

                      <Icon className="w-8 h-8 text-orange-500" />

                    </div>

                    <h3 className="text-xl font-semibold mb-2">
                      {feature.title}
                    </h3>

                    <p className="text-gray-600">
                      {feature.description}
                    </p>

                  </CardContent>

                </Card>

              );
            })}

          </div>

        </div>

      </section>


      {/* Call To Action */}

      <section className="py-20 bg-gray-50">

        <div className="container mx-auto px-4 text-center">

          <h2 className="text-3xl font-bold mb-4">
            Ready to Order Delicious Food?
          </h2>

          <p className="text-gray-600 mb-8">
            Create an account and start ordering from the best restaurants near you.
          </p>

          <Link to="/register">

            <Button
              size="lg"
              className="bg-orange-500 hover:bg-orange-600"
            >
              Sign Up Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>

          </Link>

        </div>

      </section>


      {/* Footer */}

      <footer className="bg-gray-900 text-white py-12">

        <div className="container mx-auto px-4">

          <div className="grid md:grid-cols-4 gap-8">

            <div>

              <div className="flex items-center gap-2 mb-4">
                <UtensilsCrossed className="w-6 h-6 text-orange-500" />
                <span className="text-xl font-bold">FoodHub</span>
              </div>

              <p className="text-gray-400">
                Your favorite food, delivered fast.
              </p>

            </div>


            <div>

              <h4 className="font-semibold mb-4">Company</h4>

              <ul className="space-y-2 text-gray-400">

                <li>About Us</li>
                <li>Careers</li>
                <li>Contact</li>

              </ul>

            </div>


            <div>

              <h4 className="font-semibold mb-4">For Restaurants</h4>

              <ul className="space-y-2 text-gray-400">

                <li>Partner With Us</li>
                <li>Restaurant Dashboard</li>

              </ul>

            </div>


            <div>

              <h4 className="font-semibold mb-4">Support</h4>

              <ul className="space-y-2 text-gray-400">

                <li>Help Center</li>
                <li>Terms of Service</li>
                <li>Privacy Policy</li>

              </ul>

            </div>

          </div>


          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">

            <p>
              © 2026 FoodHub. All rights reserved.
            </p>

          </div>

        </div>

      </footer>

    </div>
  );
}